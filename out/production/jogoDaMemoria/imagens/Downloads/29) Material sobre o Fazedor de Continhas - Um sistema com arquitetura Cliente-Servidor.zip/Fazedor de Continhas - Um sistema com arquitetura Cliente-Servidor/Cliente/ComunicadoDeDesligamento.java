public class ComunicadoDeDesligamento extends Comunicado
{}
