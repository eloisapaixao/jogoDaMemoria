import java.io.*;

public class Comunicado implements Serializable, Cloneable
{}
